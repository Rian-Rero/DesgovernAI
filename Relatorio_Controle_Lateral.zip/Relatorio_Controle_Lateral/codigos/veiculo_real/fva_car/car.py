# -*- coding: utf-8 -*-
########################################
# Disciplina: Topicos em Engenharia de Controle e Automacao IV (ENG075):
# Fundamentos de Veiculos Autonomos - 2026/2
# Professores: Armando Alves Neto e Leonardo A. Mozelli
# Cursos: Engenharia de Controle e Automacao
# DELT - Escola de Engenharia
# Universidade Federal de Minas Gerais
########################################
import numpy as np
import time, os
from datetime import datetime

try:
    from . import encoder, servos, buzzer, ultrasonic, filter
except ImportError:
    import encoder, servos, buzzer, ultrasonic, filter


# QUESTAO DA ORIENTACAO DO CARRINHO NA FUSAO DE POSICAO (COMECA SEMPRE PARA O LESTE)
# VERIFICAR SINAL DO GZ DA IMU
# VERIFICAR EIXO X DA ACELERACAO DA IMU
# VERIFICAR HEADING DA BUSSOLA COM NORTE MAGNETICO (yaw_geo = np.pi/2 - yaw_mag	)

########################################
# GLOBAIS
########################################
# parametros do carro
CAR = {
    "VELMAX": 2,  # m/s
    "ACCELMAX": 1.0,  # m/s^2
    "STEERMAX": np.deg2rad(20.0),  # rad
    "MASS": 5.16,  # kg
    "L": 0.36,  # distancia entre os eixos das rodas
    "RW": 0.08,  # raio da roda [m]
    "MI": 0.04,  # constante de friccao
    "GRAV": 9.81,  # gravidade [m/s^2]
    "PERIOD": 50.0,  # periodo de amostragem dos sensores
}

# controlador PI de velocidade para comando direto de throttle
KP_VEL = 1
KI_VEL = 0.8
# Feedforward = throttle de regime: THROTTLE_FF_OFFSET + THROTTLE_FF_GAIN*vref.
# Nos 11 ensaios de 10/11 (trechos em regime) o throttle foi ~0,42 a 0,3 m/s,
# 0,39 a 0,55, 0,45 a 0,65 e 0,59 a 0,9 m/s: o ESC so move o carro acima de ~0,35
# (zona morta). So com 0,17*vref (0,06 a 0,35 m/s) o integrador levava 1-2 s
# para chegar la; na partida, com o PI oscilando em volta da zona morta, o motor
# ligava e desligava (o "engasgo"). O offset fica um pouco abaixo da zona morta:
# o PI completa. Outro carro/ESC/bateria pode pedir outro valor (veja o u em
# regime no car.csv).
THROTTLE_FF_OFFSET = 0.32  # throttle com vref > 0
THROTTLE_FF_GAIN = 0.22  # fracao de throttle por m/s
VELOCITY_FILTER_SIZE = 5

MACS_CARS = {
    "verde": "2c:cf:67:1c:29:4a",
    "vermelho": "d8:3a:dd:f1:8a:4f",
    "roxo": "2c:cf:67:1c:29:07",
}

COLORS = {"verde": "\033[32m", "vermelho": "\033[31m", "roxo": "\033[35m"}

RESET = "\033[0m"


########################################
# Carrinho
########################################
class Car:
    ########################################
    # construtor
    def __init__(self, parameters):

        self.parameters = parameters
        # Feedforward do acelerador (veja THROTTLE_FF_OFFSET): ajustavel por carro
        # sem editar o codigo (main.py --throttle-offset / campo da GUI).
        self.ff_offset = float(parameters.get("throttle_ff_offset", THROTTLE_FF_OFFSET))
        self.ff_gain = float(parameters.get("throttle_ff_gain", THROTTLE_FF_GAIN))
        # Escala do comando do SERVO por lado (direcao mais forte para um lado):
        # o servo recebe esterco*escala; self.st (odometria) continua o esterco
        # desejado, que e o que a roda faz com a escala certa. 1 = sem correcao.
        self.steer_scale_left = float(parameters.get("steering_left_scale", 1.0))
        self.steer_scale_right = float(parameters.get("steering_right_scale", 1.0))
        # Mapa aprendido do throttle de regime (fva_car/throttle.py); None: so a reta acima.
        self.throttle_map = None
        if parameters.get("throttle_learning", False):
            from .throttle import ThrottleMap

            self.throttle_map = ThrottleMap.from_dict(parameters.get("throttle_map"), self.ff_offset, self.ff_gain)

        # detecta carrinho pronto
        self.color = self.get_car_color()

        # inicializa sensores
        self.init_sensors()

        # tempo
        self.t = 0.0
        # tempo de amostragem preterido
        self.sample_rate = 1.0 / CAR["PERIOD"]
        # tempo de amostragem real medido
        self.dt = 1.0 / CAR["PERIOD"]

        # velocidade de referencia
        self.vref = 0.0

        # variaveis calculadas
        self.p_offset = np.array(parameters["initial_position"][:2], dtype=float)
        self.p = self.p_offset.copy()
        self.th = parameters["initial_position"][2]
        self.w = 0.0
        self.v = 0.0
        self.a = 0.0
        self.p_gps = None

        # monitorar calibracao
        self.a_model = 0.0
        self.a_x = 0.0
        self.w_model = 0.0
        self.w_imu = 0.0
        self.yaw_mag = float('nan')

        # comando de aceleracao
        self.u = 0.0
        # comando de estercamento
        self.st = 0.0
        self.st_filtered = 0.0

        # Receptor e seletores independentes: 0 = RC, 1 = AUTO.
        self.rc_direcao = 0.0
        self.rc_acelerador = 0.0
        self.sel_direcao = 0
        self.sel_tracao = 0
        self.encoder_valid = False

        # botao de emergencia
        self.emergencia = True

        # marcha atual
        self.gear = self.atuador.get_gear()

        # filtros dos sinais
        self.v_filt = filter.MovingAverage(n=VELOCITY_FILTER_SIZE)
        self.a_filt = filter.MovingAverage(n=30)
        self.w_filt = filter.MovingAverage(n=10)
        self.vel_error_integral = 0.0

        # logs de salvamento
        if self.parameters["save"]:
            # logs de salvamento
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.logfile = os.path.join(parameters["logfile"], timestamp)
            # cria a pasta do experimento
            os.makedirs(self.logfile, exist_ok=True)

    ########################################
    # inicializa sensores e atuadores
    def init_sensors(self):

        # atuadores de estercamento, aceleracao e ultrasom/camera
        try:
            self.atuador = servos.Servos(
                steering_filter_size=self.parameters.get('steering_filter_size', 10)
            )
        except Exception as e:
            print(f"\033[31mErro nos servos: {e}\033[0m", flush=True)
            raise

        # odometro da roda
        try:
            self.odometer = encoder.Encoder(
                protocol=self.parameters.get("encoder_protocol", "rc")
            )
        except Exception as e:
            print(f"\033[31mErro no velocimetro: {e}\033[0m", flush=True)
            raise

        # IMU desativada para operar sem o sensor no barramento I2C.
        # self.imu = imu.IMU()

        # ultrasom
        try:
            self.us = ultrasonic.Ultrasonic()
        except Exception as e:
            print(f"\033[31mErro no ultrasom: {e}\033[0m", flush=True)
            raise

        # buzzer de sinalizacao
        try:
            self.bz = buzzer.Buzzer()
        except Exception as e:
            print(f"\033[31mErro no buzzer: {e}\033[0m", flush=True)
            raise

        # camera
        if self.parameters["camera"]:
            try:
                from . import camera

                self.cam = camera.Camera(**self.parameters.get("camera_settings", {}))
            except Exception as e:
                print(f"\033[31mErro na camera: {e}\033[0m", flush=True)
                raise
        else:
            print("\033[33mCamera desativada.\033[0m", flush=True)

        # GPS opcional (via celular android)
        try:
            from . import gps

            self.gps = gps.GPS()

            if self.gps.is_available():
                print("\033[32mGPS disponivel.\033[0m", flush=True)
            else:
                # sem GPS, use apenas odometria
                self.gps = None
                print("\033[33mGPS nao disponivel.\033[0m", flush=True)
        except Exception as e:
            self.gps = None
            print(f"\033[33mGPS nao disponivel: {e}\033[0m", flush=True)

        # carro pronto
        if self.color is not None:
            print(
                f"{COLORS[self.color]}##############################{RESET}", flush=True
            )
            print(
                f"{COLORS[self.color]}Carro {self.color.upper()} pronto!{RESET}",
                flush=True,
            )
            print(
                f"{COLORS[self.color]}##############################{RESET}", flush=True
            )
        else:
            print("\033[33m##############################\033[0m", flush=True)
            print("\033[33mCarro desconhecido pronto!\033[0m", flush=True)
            print("\033[33m##############################\033[0m", flush=True)

    ########################################
    # comeca a missao
    def start_mission(self):

        # desliga a emergencia
        self.emergencia = False

        # define origem do GPS, se disponivel
        if self.gps is not None:
            if self.gps.set_origin():
                print("\033[32mOrigem GPS definida.\033[0m", flush=True)

                # _, _, yaw_mag = self.imu.get_euler(degrees=False)
            else:
                print("\033[33mNao foi possivel definir origem GPS.\033[0m", flush=True)

        # tempo inicial
        self.tinit = self.get_time()

        # estados iniciais
        self.get_states()

        # comeca parado
        self.set_u(0.0)
        self.set_steer(0.0)

        # salva trajetoria
        self.save_traj()

        # aviso sonoro de inicio
        self.bz.beep([0.2] * 3)
        time.sleep(1.0)

        # desconsidera o tempo do beep no primeiro passo de controle
        self.t = self.get_time() - self.tinit
        self.dt = self.sample_rate

    ########################################
    # get states
    def get_states(self):

        # velocidade
        self.v_ant = self.v
        self.v, self.w = self.get_vel()

        # O protocolo RPM usa AUTO; o protocolo RC recebe as chaves do Arduino.
        self.rc_direcao, self.rc_acelerador = self.odometer.get_rc()
        self.encoder_valid = bool(self.odometer.control_valid())
        previous_traction_mode = self.sel_tracao
        self.sel_direcao, self.sel_tracao = self.odometer.get_control_mode()
        if self.sel_tracao != previous_traction_mode:
            self.vel_error_integral = 0.0

        # aceleracao
        self.a = self.get_accel()

        # orientacao
        self.th = self.get_yaw()

        # posicao
        self.p = self.get_pos()

        # tempo
        self.t = self.get_time() - self.tinit

        return self.p, self.v, self.a, self.th, self.w, self.t

    ########################################
    # passo para atualizar sensores
    def step(self):

        try:
            # tempo anterior
            t0 = self.t

            # espera o periodo de delta t
            elapsed_time = self.get_time() - self.tinit - t0
            time.sleep(np.max([0.0, self.sample_rate - elapsed_time]))

            # condicoes iniciais
            self.get_states()

            # atualiza amostragem
            self.dt = self.t - t0

            # se esta dando re, avise
            if self.gear == servos.Gear.REVERSE:
                self.bz.beep(0.3, silence=0.5)

            # salva trajetoria
            self.save_traj()

            return True

        except KeyboardInterrupt:
            print("\nInterrupcao solicitada pelo usuario.")
            return False

    ########################################
    # retorna tempo do sistema
    def get_time(self):
        return float(time.monotonic())

    ########################################
    # retorna posicao estimada do carro
    def get_pos(self):

        # predicao pelo modelo cinematico
        x = self.p[0] + self.v * np.cos(self.th) * self.dt
        y = self.p[1] + self.v * np.sin(self.th) * self.dt
        p = np.array((x, y))

        # correcao com GPS, se disponivel
        if self.gps is not None:
            position = self.gps.get_position()
            accuracy = self.gps.get_accuracy()

            # se posicao eh nova
            if position is not None and self.gps.new_position:
                p_gps = self.gps.get_xy(position)

                if p_gps is not None:
                    # soma offset de posicao relativa
                    self.p_gps = self.p_offset + np.array(p_gps)

                    # fusao sensorial simples
                    K = 0.1
                    p = (1.0 - K) * p + K * self.p_gps

        # retorna posicao
        return p

    ########################################
    # retorna yaw estimado pelo modelo cinematico
    def get_yaw(self):

        # predicao pela integracao da velocidade angular
        yaw = self.th + self.w * self.dt

        # _, _, self.yaw_mag = self.imu.get_euler(degrees=False)

        # mantem entre 0 e 2*pi
        yaw = yaw % (2.0 * np.pi)

        return yaw

    ########################################
    # retorna velocidades linear e angular
    def get_vel(self):

        # le velocidade do encoder
        v, valid = self.odometer.get_vel()

        # somente atualiza velocidade se a medida for valida
        if valid:
            vf = self.v_filt.filter(v)
        else:
            vf = self.v

        # velocidade angular pelo modelo cinematico
        self.w_model = (vf / CAR["L"]) * np.tan(self.st)

        # _, _, g_z = self.imu.get_gyro()
        self.w_imu = float('nan')

        # filtra velocidade angular
        wf = self.w_filt.filter(self.w_model)

        return vf, wf

    ########################################
    # retorna aceleracao
    def get_accel(self):

        if self.dt > 0.0:
            # aceleracao pelo encoder
            self.a_model = (self.v - self.v_ant) / self.dt
        else:
            self.a_model = 0.0

        # self.a_x, _, _ = self.imu.get_accel()
        self.a_x = float('nan')

        # filtra
        af = self.a_filt.filter(self.a_model)

        return af

    ########################################
    # seta referencia de controle
    def _set_ref(self, vref):
        # em caso de emergencia, pare
        if self.emergencia:
            self.vref = 0.0
            return self.vref

        # a velocidade medida ja esta filtrada; a referencia entra sem atraso
        self.vref = float(np.clip(vref, -CAR["VELMAX"], CAR["VELMAX"]))

        # se eh para dar re e estou indo para frente
        if (self.vref < 0.0) and (self.gear == servos.Gear.FORWARD):
            self.set_reverse()

        # se eh para ir para frente e estou dando re
        elif (self.vref > 0.0) and (self.gear == servos.Gear.REVERSE):
            self.set_forward()

        return self.vref

    ########################################
    # revalida a comunicacao inclusive depois de uma troca de marcha
    def _encoder_ready(self):
        valid = bool(getattr(self, "encoder_valid", False))
        odometer = getattr(self, "odometer", None)
        if valid and odometer is not None:
            valid = bool(odometer.control_valid())
        self.encoder_valid = valid
        return valid

    ########################################
    # seta torque do veiculo
    def set_vel(self, vref):

        if not self._encoder_ready():
            self._set_ref(0.0)
            self.vel_error_integral = 0.0
            self.set_u(0.0)
            return

        # Em RC, o receptor escolhe a referencia; em AUTO, preserva o PI local.
        if self.sel_tracao == 0:
            vref = self.rc_acelerador * CAR["VELMAX"]

        # define referencia e marcha
        self._set_ref(vref)

        # erro usando a velocidade medida com filtro de media
        vref_abs = abs(self.vref)
        v_abs = abs(self.v)
        error = vref_abs - v_abs

        # feedforward fornece o throttle de regime; o PI faz a correcao
        offset = getattr(self, "ff_offset", THROTTLE_FF_OFFSET)
        gain = getattr(self, "ff_gain", THROTTLE_FF_GAIN)
        throttle_map = getattr(self, "throttle_map", None)
        if throttle_map is not None:
            feedforward = throttle_map.feedforward(vref_abs)
        else:
            feedforward = offset + gain * vref_abs if vref_abs > 0.05 else 0.0
        u = feedforward + KP_VEL * error + KI_VEL * self.vel_error_integral
        u_sat = np.clip(u, 0.0, 1.0)

        # anti-windup: integra apenas fora da saturacao ou para sair dela
        if (u == u_sat) or (u > u_sat and error < 0.0) or (u < u_sat and error > 0.0):
            dt_control = min(self.dt, 2.0 * self.sample_rate)
            self.vel_error_integral += error * dt_control
            u = feedforward + KP_VEL * error + KI_VEL * self.vel_error_integral

        self.set_u(u)
        # Em regime (na referencia, sem saturar, sem acelerar): o throttle aplicado
        # e o que esta velocidade pede. So no automatico (no RC a vref e do radio).
        if (throttle_map is not None and self.sel_tracao != 0 and vref_abs > 0.15 and abs(error) < 0.04
                and 0.0 < self.u < 1.0 and abs(getattr(self, "a", 0.0)) < 0.4):
            throttle_map.update(v_abs, self.u, min(self.dt, 2.0 * self.sample_rate))

    ########################################
    # seta throttle dos motores do veiculo
    def set_u(self, u):

        # em caso de emergencia, corte o throttle
        if not self._encoder_ready():
            self.vref = 0.0
            self.vel_error_integral = 0.0
            u = 0.0
        if self.emergencia:
            u = 0.0

        # limita comando entre neutro e throttle maximo
        self.u = float(np.clip(u, 0.0, 1.0))

        # acima do limite, corte o throttle
        if np.abs(self.v) > CAR["VELMAX"]:
            self.u = 0.0

        # seta diretamente a fracao de throttle
        self.atuador.set_throttle(self.u)

    ########################################
    # coloca re
    def set_reverse(self):
        self.atuador.set_reverse()
        self.gear = self.atuador.get_gear()
        self.vel_error_integral = 0.0

    ########################################
    # vai pra frente
    def set_forward(self):
        self.atuador.set_forward()
        self.gear = self.atuador.get_gear()
        self.vel_error_integral = 0.0

    ########################################
    # seta steer do veiculo
    def set_steer_trim(self, trim):
        """Centro da direcao (rad, esquerda +) somado no servo. self.st (usado na
        odometria) continua sendo o esterco pretendido: com o centro certo, a
        roda faz o que a odometria supoe."""
        trim = float(trim) if np.isfinite(trim) else 0.0
        self.atuador.set_trim(steer=trim, throttle=getattr(self.atuador, "trim_throttle", 0.0))
        return trim

    def set_steer(self, st):
        # emergencia
        if self.emergencia or not self._encoder_ready():
            st = 0.0
        elif self.sel_direcao == 0:
            st = self.rc_direcao * CAR["STEERMAX"]

        # limita angulo de estercamento
        self.st = np.clip(st, -CAR["STEERMAX"], CAR["STEERMAX"])

        # atua no volante (escala por lado so no comando do servo, no automatico)
        command = self.st
        if self.sel_direcao != 0:
            scale = (getattr(self, "steer_scale_left", 1.0) if command > 0
                     else getattr(self, "steer_scale_right", 1.0))
            command = float(np.clip(command*scale, -CAR["STEERMAX"], CAR["STEERMAX"]))
        filtered = self.atuador.set_steer(command)
        self.st_filtered = (float(filtered) if isinstance(filtered, (int, float, np.number))
                            and np.isfinite(filtered) else float('nan'))

    ########################################
    # get image data
    def get_image(self, gray=False):
        return self.cam.get_image(gray)

    ########################################
    # get ultrasonic distance
    def get_distance(self, max_dist=4.0, d_min=0.3):

        # captura a distancia
        d, valid = self.us.get_distance()
        d = np.clip(d, ultrasonic.MIN_RANGE, min(max_dist, ultrasonic.MAX_RANGE))

        # toca o buzzer se muito proximo
        if self.parameters["us_buzzer"]:
            if d <= d_min:
                self.bz.beep(d / 3.0)

        # retorna distancia
        return d, valid

    ########################################
    # salva a trajetoria
    def save_traj(self):

        # dados (COLOCAR APENAS ESCALARES)
        data = {
            "t": self.t,
            "x": self.p[0],
            "y": self.p[1],
            "v": self.v,
            "a": self.a,
            "vref": self.vref,
            "th": self.th,
            "w": self.w,
            "u": self.u,
            "a_model": self.a_model,
            "a_x": self.a_x,
            "w_model": self.w_model,
            "w_imu": self.w_imu,
            "yaw_mag": self.yaw_mag,
            "rc_direcao": self.rc_direcao,
            "rc_acelerador": self.rc_acelerador,
            "sel_direcao": self.sel_direcao,
            "sel_tracao": self.sel_tracao,
            "encoder_valid": int(self.encoder_valid),
            "steer_filtered_rad": self.st_filtered,
        }

        # se ja iniciou as trajetorias
        try:
            self.traj.append(data)
        # se for a primeira vez
        except:
            self.traj = [data]

    ########################################
    # acrescenta telemetria a amostra atual
    def log(self, **values):
        if getattr(self, "traj", None):
            self.traj[-1].update(values)

    ########################################
    # salva trajetoria em csv
    def save(self):

        filename = os.path.join(self.logfile, "car.csv")

        keys = list(dict.fromkeys(key for row in self.traj for key in row))
        header = ",".join(keys)
        data = np.array([[row.get(key, np.nan) for key in keys]
                         for row in self.traj], dtype=float)

        np.savetxt(filename, data, delimiter=",", header=header, comments="")

    ########################################
    # termina a missao
    def stop_mission(self):

        # aperta a emergencia
        self.emergencia = True

        # termina parado
        self.set_u(-CAR["ACCELMAX"])
        self.set_steer(0.0)

        # tenta parar por no maximo alguns segundos
        t0 = self.get_time()
        while abs(self.v) > 0.1:
            self.step()
            time.sleep(0.1)
            # nao espera para sempre
            if self.get_time() - t0 > 3.0:
                break

        # sinaliza fim
        time.sleep(1.0)
        self.bz.victory_tune()

    ########################################
    # qual eh o carrinho?
    def get_car_color(self):

        # procura os MACs das interfaces de rede
        for interface in os.listdir("/sys/class/net"):
            path = f"/sys/class/net/{interface}/address"
            try:
                with open(path, "r") as f:
                    mac = f.read().strip().lower()
            except OSError:
                continue
            # procura o MAC conhecido
            for color, known_mac in MACS_CARS.items():
                if mac == known_mac.lower():
                    return color

        return None

    ########################################
    # termina a classe
    def close(self):
        # para o carrinho
        self.stop_mission()

        # fecha tudo
        self.bz.close()
        self.odometer.close()
        self.atuador.close()
        self.us.close()
        # self.imu.close()
        if self.parameters["camera"]:
            self.cam.close()
        if self.gps is not None:
            self.gps.close()

        # acabou
        if self.color is not None:
            print(
                f"{COLORS[self.color]}##############################{RESET}", flush=True
            )
            print(f"{COLORS[self.color]}Missao terminada!{RESET}", flush=True)
            print(
                f"{COLORS[self.color]}##############################{RESET}", flush=True
            )
        else:
            print("\033[33m##############################\033[0m", flush=True)
            print("\033[33mMissao terminada!\033[0m", flush=True)
            print("\033[33m##############################\033[0m", flush=True)


########################################
# main teste
########################################
if __name__ == "__main__":

    # Globais
    parameters = {
        "ts": 30.0,  # tempo da execucao
        "save": True,  # salva dados da trajetoria
        "logfile": "logs/",  # log file
        "camera": False,  # habilitar camera e thread de visao
        "ultrasonic_steering": False,  # mover ultrasom com estercamento
        "us_buzzer": True,  # aviso sonoro para objetos proximos
        "initial_position": [0, 0, np.deg2rad(0)],  # (x, y, theta) configuracao inicial
    }

    # cria comunicacao com o carrinho
    car = Car(parameters)

    try:
        car.start_mission()

        # testa leitura
        t0 = time.monotonic()
        while (time.monotonic() - t0) <= parameters["ts"]:
            t = time.monotonic() - t0

            # le sensores
            car.step()

            # le ultrasom
            dist, _ = car.get_distance()
            # seta torque do motor
            if dist > 0.30:
                if t < parameters["ts"] / 2:
                    car.set_vel(0.7)
                else:
                    car.set_vel(-0.7)
            else:
                car.set_vel(0.0)
            #
            print(
                f"Vel: {car.v:+.2f} m/s | "
                f"Ref: {car.vref:+.2f} m/s | "
                f"Marcha: {car.gear.value}"
            )

            # seta estercamento junto com ultrasom
            car.set_steer(np.deg2rad(20.0) * np.sin(0.5 * t))

        # salva os dados coletados
        if parameters["save"]:
            car.save()

    finally:
        car.close()
