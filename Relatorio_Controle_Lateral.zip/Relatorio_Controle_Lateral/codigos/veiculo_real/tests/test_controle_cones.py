"""Pure pursuit, previa de curva e rampa da vref (fva_car/lateral.py) e config do main."""
import math
from pathlib import Path
import sys
import unittest

from types import SimpleNamespace
from unittest.mock import Mock

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fva_car.lateral import (LineObservation, RealStanleyFollower, path_points, preview_speed,  # noqa: E402
                             pure_pursuit_steer)
import main  # noqa: E402
from test_lateral import fake_car  # noqa: E402

L = .36


class PathGeometryTests(unittest.TestCase):
    def test_path_points_on_a_circle(self):
        kappa = .5
        points = path_points((0., 0., kappa), 0., [1., 2.])
        for s, (x, y) in zip((1., 2.), points):
            self.assertAlmostEqual(x, math.sin(kappa*s)/kappa, places=3)
            self.assertAlmostEqual(y, (1 - math.cos(kappa*s))/kappa, places=3)

    def test_pure_pursuit_steady_state_on_a_circle(self):
        # Regime: traseiro num circulo de raio R, dianteiro no centro do corredor
        # (raio sqrt(R^2+L^2), rumo atan(L/R) em relacao ao carro).
        for radius in (1.5, -2.5, 4.):
            for lookahead in (.4, 1.):
                with self.subTest(radius=radius, lookahead=lookahead):
                    sign = math.copysign(1., radius)
                    front = math.hypot(radius, L)
                    errors = (0., sign*math.atan(L/abs(radius)), sign/front)
                    steer, _, _ = pure_pursuit_steer(errors, 0., lookahead, L)
                    self.assertAlmostEqual(steer, math.atan(L/radius), delta=.002)

    def test_pure_pursuit_turns_toward_the_path(self):
        self.assertGreater(pure_pursuit_steer((.2, 0., 0.), 0., .6, L)[0], 0.)   # centro a esquerda
        self.assertLess(pure_pursuit_steer((0., -.2, 0.), 0., .6, L)[0], 0.)     # caminho virando a direita

    def test_preview_slows_before_a_curve_it_can_only_coast_into(self):
        reference = 1.5
        straight, _, _ = preview_speed((0., 0., 0.), 0., reference, 2.5)
        self.assertEqual(straight, reference)
        # Curva de raio 2 m comecando ~1 m a frente (clotoide).
        ahead, kappa, where = preview_speed((0., 0., 0.), .5, reference, 2.5, lateral_accel=.4,
                                            deceleration=.5, speed=1.5)
        bend = math.sqrt(.4/1.25)
        self.assertLess(ahead, reference)
        self.assertGreater(ahead, bend)        # ainda pode rolar ate la
        self.assertAlmostEqual(kappa, 1.25, places=2)
        self.assertAlmostEqual(where, 2.5, places=2)
        inside, _, _ = preview_speed((0., 0., .5), 0., reference, 2.5, lateral_accel=.4)
        self.assertAlmostEqual(inside, math.sqrt(.4/.5), places=3)


class SightLimitTests(unittest.TestCase):
    def test_straight_top_speed_is_what_still_lets_it_coast_into_the_tightest_curve(self):
        # Reta vista ate 2,5 m; depois pode vir curva de R = 1,5 m. Carro so rola (0,5 m/s^2).
        speed = 2.
        for _ in range(30):  # ponto fixo: a reacao depende da velocidade atual
            speed, kappa, where = preview_speed((0., 0., 0.), 0., 2., 2.5, lateral_accel=.4,
                                                deceleration=.5, speed=speed, sight_curvature=1/1.5)
        bend = math.sqrt(.4*1.5)
        self.assertAlmostEqual(where, 2.5)
        self.assertGreater(speed, 1.4)    # corre bem mais que a curva...
        self.assertLess(speed, 1.75)      # ...mas so o que ainda da para rolar ate ela
        self.assertAlmostEqual(speed**2, bend**2 + 2*.5*(2.5 - .3*speed), places=2)
        # Sem o limite, so curvas vistas reduzem: na reta fica na referencia.
        self.assertEqual(preview_speed((0., 0., 0.), 0., 2., 2.5, lateral_accel=.4)[0], 2.)

    def test_mission_turns_min_radius_into_sight_limit_only_with_estimator(self):
        config = dict(main.parameters)
        self.assertAlmostEqual(main.follower_config(config, 'cones', {})['speed_sight_curvature'],
                               1/config['min_curve_radius_m'])
        self.assertEqual(main.follower_config(dict(config, min_curve_radius_m=0), 'cones', {})
                         ['speed_sight_curvature'], 0.)
        self.assertEqual(main.follower_config(config, 'cones', None)['speed_sight_curvature'], 0.)
        self.assertNotIn('speed_sight_curvature', main.follower_config(config, 'line', None))


class FollowerTests(unittest.TestCase):
    settings = dict(velocity_reference=1., curve_min_speed=.2, vision_latency_compensation=False,
                    speed_filter_s=0.)

    def apply(self, follower, observation, car=None, now=10.):
        car = car or fake_car()
        follower.apply(car, observation, now)
        return car

    def test_pure_pursuit_needs_the_estimator_path(self):
        follower = RealStanleyFollower(dict(self.settings, steering_law='pure_pursuit'))
        self.apply(follower, LineObservation(10., errors=(.1, 0., 0.), path_dkappa=0.))
        self.assertEqual(follower.last_state['steering_law'], 'pure_pursuit')
        self.assertIsNotNone(follower.last_state['pursuit'])
        follower = RealStanleyFollower(dict(self.settings, steering_law='pure_pursuit'))
        self.apply(follower, LineObservation(10., errors=(.1, 0., 0.)))  # linha amarela: sem dkappa
        self.assertEqual(follower.last_state['steering_law'], 'stanley')

    def test_invalid_steering_law_is_rejected(self):
        with self.assertRaises(ValueError):
            RealStanleyFollower({'steering_law': 'mpc'})

    def test_preview_reduces_vref_before_the_curve(self):
        # Reta agora, curva fechada 1 m a frente: a 2 m/s nao da para rolar ate ela.
        settings = dict(self.settings, velocity_reference=2.)
        plain = self.apply(RealStanleyFollower(settings),
                           LineObservation(10., errors=(0., 0., 0.), path_dkappa=1.))
        preview = self.apply(RealStanleyFollower(dict(settings, speed_preview_m=2.5)),
                             LineObservation(10., errors=(0., 0., 0.), path_dkappa=1.))
        self.assertAlmostEqual(plain.vref, 2., places=3)
        self.assertLess(preview.vref, 1.3)

    def test_vref_rises_in_a_ramp_and_falls_at_once(self):
        follower = RealStanleyFollower(dict(self.settings, speed_rise_m_s2=1., curvature_filter_s=0.))
        car = fake_car()
        car.dt = .02
        self.apply(follower, LineObservation(10., errors=(0., 0., 0.)), car, 10.)
        # Primeiro passo: a rampa parte da velocidade medida (0,4), nao salta para 1.
        self.assertAlmostEqual(car.vref, .42, places=3)
        follower.speed_target = .3
        self.apply(follower, LineObservation(10.02, errors=(0., 0., 0.)), car, 10.02)
        self.assertAlmostEqual(car.vref, .32, places=3)  # sobe 1 m/s^2 * 0,02 s
        follower.speed_target = 1.
        self.apply(follower, LineObservation(10.04, errors=(0., 0., 1.)), car, 10.04)
        self.assertAlmostEqual(car.vref, math.sqrt(.4/1.), places=2)  # curva: desce na hora


class StartupTests(unittest.TestCase):
    """Partida sem "engasgo": velocidade de recuperacao so com o caminho a frente
    incerto, alvo longe enquanto o eixo e incerto, rampa a partir da velocidade."""
    def test_far_cones_do_not_hold_the_car_at_recovery_speed(self):
        from fva_car.corridor import CorridorEstimator, CorridorSettings
        from fva_car.lateral import GroundCalibration
        calibration = GroundCalibration.from_file(Path(__file__).resolve().parent/'dados'/'camera_pista_virtual.json')
        estimator = CorridorEstimator(CorridorSettings(track_width_m=1.2), calibration.homography)
        x = np.array([.8, 1.2, 1.6, 2.1])  # partida: nenhum cone junto ao eixo
        estimate = estimator.step(10., np.c_[x, np.full(4, .6)], np.c_[x, np.full(4, -.6)], (0., 0., 0.))
        self.assertTrue(estimate.valid)
        self.assertGreater(estimate.sigma[0], .1)       # antes: so isso ja segurava a 0,35 m/s
        self.assertLess(estimator.lateral_sigma(1., given_width=True), .1)
        self.assertFalse(estimate.slow)
        self.assertTrue(estimate.near_uncertain)        # mas mira longe

    def test_uncertain_axle_moves_the_pursuit_target_out(self):
        settings = dict(FollowerTests.settings, steering_law='pure_pursuit')
        car = fake_car()
        follower = RealStanleyFollower(settings)
        follower.apply(car, LineObservation(10., errors=(.1, 0., 0.), path_dkappa=0.), 10.)
        self.assertLess(follower.pursuit_target[0], .8)
        follower = RealStanleyFollower(settings)
        follower.apply(car, LineObservation(10., errors=(.1, 0., 0.), path_dkappa=0., min_lookahead_m=1.), 10.)
        self.assertAlmostEqual(follower.pursuit_target[0], 1.)

    def test_settling_estimator_widens_the_jump_gate(self):
        def rejected(sigma):
            follower = RealStanleyFollower(dict(FollowerTests.settings, max_lateral_jump_m=.25))
            car = fake_car()
            car.v = 0.
            follower.apply(car, LineObservation(10., errors=(0., 0., 0.), lateral_sigma_m=sigma), 10.)
            follower.apply(car, LineObservation(10.1, errors=(.35, 0., 0.), lateral_sigma_m=sigma), 10.1)
            return follower.frame_rejected
        self.assertTrue(rejected(float('nan')))
        self.assertTrue(rejected(.02))
        self.assertFalse(rejected(.3))  # 0,25 + 3*0,3: correcao legitima do estimador


class CenteringTests(unittest.TestCase):
    settings = dict(velocity_reference=1., curve_min_speed=.2, vision_latency_compensation=False,
                    speed_filter_s=0., centering_gain=.5)

    def run_steps(self, errors, steps=100, **extra):
        follower = RealStanleyFollower(dict(self.settings, **extra))
        car = fake_car()
        car.v, car.dt = .6, .02
        trims = []
        car.set_steer_trim = Mock(side_effect=lambda trim: trims.append(trim))
        for k in range(steps):
            now = 10. + k*car.dt
            follower.apply(car, LineObservation(now, errors=errors, path_dkappa=0.), now)
        return follower, car, trims

    def test_constant_offset_on_a_straight_becomes_servo_trim(self):
        # Centro 5 cm a esquerda o tempo todo (vies do carro): trim para a esquerda.
        follower, car, trims = self.run_steps((.05, 0., 0.))
        self.assertAlmostEqual(follower.centering, .5*.05*100*.02, places=4)
        self.assertGreater(trims[-1], 0.)
        self.assertAlmostEqual(follower.centering_time, 2., places=6)
        # O trim vai para o servo: o esterco pretendido (odometria) nao o inclui.
        self.assertLess(abs(car.st - follower.controller.steer), 1e-9)

    def test_mean_steering_on_a_straight_becomes_servo_trim(self):
        # Para seguir a reta o carro comanda 1 grau a esquerda: o servo puxa para
        # a direita. O trim vai para a esquerda ate o comando medio zerar.
        follower = RealStanleyFollower(dict(self.settings, centering_gain=0., centering_steer_gain=.3))
        car = fake_car()
        car.v, car.dt = .6, .02
        follower.controller.steer = math.radians(1.)
        follower.controller.target_steer = math.radians(1.)
        follower.apply(car, LineObservation(10., errors=(0., 0., 0.), path_dkappa=0.), 10.)
        self.assertAlmostEqual(follower.centering, .3*math.radians(1.)*.02, places=6)
        self.assertGreater(follower.centering_time, 0.)

    def test_mission_learns_trim_from_the_mean_steering(self):
        self.assertGreater(main.parameters['centering_steer_gain'], 0.)
        self.assertEqual(main.parameters['centering_gain'], 0.)

    def test_no_learning_in_curves_with_one_border_or_disabled(self):
        for errors, extra in (((.05, 0., .5), {}),                    # curva
                              ((.05, 0., 0.), {'centering_gain': 0.})):  # desligado
            with self.subTest(errors=errors, extra=extra):
                follower, _, _ = self.run_steps(errors, **extra)
                self.assertEqual(follower.centering, 0.)
        follower = RealStanleyFollower(self.settings)
        car = fake_car()
        car.v = .6
        follower.apply(car, LineObservation(10., errors=(.05, 0., 0.), speed_factor=.8), 10.)  # uma borda so
        self.assertEqual(follower.centering, 0.)

    def test_trim_is_saved_for_the_next_run_and_loaded_back(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'direcao_trim.json'
            config = dict(main.parameters, steering_trim_deg=1.0)
            follower = SimpleNamespace(centering=math.radians(2.), centering_time=5.)
            self.assertAlmostEqual(main.save_steering_trim(follower, config, path), 2.0)  # 1 + 0,5*2
            self.assertAlmostEqual(main.load_steering_trim(dict(config, steering_trim_deg=0.), path), 2.0)
            short = SimpleNamespace(centering=math.radians(2.), centering_time=1.)  # pouca reta: nao salva
            self.assertIsNone(main.save_steering_trim(short, config, path))
            off = dict(config, steering_trim_learning=False)
            self.assertEqual(main.load_steering_trim(off, path), 1.0)
            self.assertIsNone(main.save_steering_trim(follower, off, path))


class MissionConfigTests(unittest.TestCase):
    def test_line_mode_and_legacy_cones_keep_stanley(self):
        config = dict(main.parameters)
        self.assertEqual(main.follower_config(config, 'cones', {})['steering_law'], 'stanley')  # padrao
        pursuit = dict(config, steering_law='pure_pursuit')
        self.assertEqual(main.follower_config(pursuit, 'cones', {})['steering_law'], 'pure_pursuit')
        for mode, corridor in (('line', None), ('cones', None)):
            derived = main.follower_config(config, mode, corridor)
            self.assertEqual(derived['steering_law'], 'stanley')
            self.assertEqual(derived['speed_preview_m'], 0.)
            self.assertEqual(derived['speed_rise_m_s2'], 0.)


if __name__ == '__main__':
    unittest.main()


class StanleySpeedTests(unittest.TestCase):
    """Termo de deslocamento do Stanley com a velocidade MEDIDA filtrada (k fixo)."""
    def follower(self, **extra):
        return RealStanleyFollower(dict(FollowerTests.settings, steering_law='stanley', stanley_use_vref=False,
                                        stanley_speed_filter_s=.3, **extra))

    def test_noisy_encoder_is_smoothed_and_follows_the_real_speed(self):
        follower = self.follower()
        rng = np.random.default_rng(0)
        speeds = []
        for k in range(150):  # 3 s a 0,5 m/s com o encoder oscilando +-0,15 m/s
            speeds.append(follower._filter_measured_speed(.5 + rng.normal(0., .15), .02))
        tail = np.array(speeds[50:])
        self.assertAlmostEqual(float(tail.mean()), .5, delta=.03)
        self.assertLess(float(tail.std()), .05)   # 3x menos que o encoder
        for _ in range(100):  # freou: acompanha (constante de 0,3 s)
            value = follower._filter_measured_speed(.1, .02)
        self.assertAlmostEqual(value, .1, delta=.01)

    def test_stanley_uses_the_filtered_speed_not_the_reference(self):
        follower = self.follower()
        car = fake_car()
        car.v, car.vref = .2, 1.  # partida/curva: o carro ainda esta lento
        follower.apply(car, LineObservation(10., errors=(.1, 0., 0.)), 10.)
        self.assertAlmostEqual(follower.last_state.get('stanley_speed_m_s', car.v), .2, delta=1e-6)
        k, ks = follower.controller.gain, follower.controller.softening
        self.assertAlmostEqual(follower.controller.cross_track_term, math.atan2(k*.1, .2 + ks), places=6)


class CorridorRecoveryTests(unittest.TestCase):
    def test_two_cones_restart_once_the_width_is_known(self):
        from fva_car.corridor import CorridorEstimator, CorridorSettings
        est = CorridorEstimator(CorridorSettings(track_width_m=1.3))
        two = np.array([[1.2, -.65], [2., -.65]])
        self.assertFalse(est.step(10., [], two, None).valid)   # largura nunca medida: precisa de 3
        est = CorridorEstimator(CorridorSettings(track_width_m=1.3))
        est.learned_width = 1.3
        est.step(10., [], two, None)
        self.assertIsNotNone(est.x)  # com a largura aprendida, 2 bastam

    def test_memory_lasts_long_enough_for_a_slow_turn(self):
        from fva_car.corridor import CorridorEstimator, CorridorSettings
        est = CorridorEstimator(CorridorSettings(track_width_m=1.3))
        left = np.c_[np.linspace(1., 2.2, 4), np.full(4, .65)]
        right = np.c_[np.linspace(1., 2.2, 4), np.full(4, -.65)]
        est.step(10., left, right, None)
        state = None
        for k in range(1, 9):  # 1,6 s sem cones a 0,15 m/s (24 cm): segue na memoria
            state = est.step(10. + .2*k, [], [], (.03, 0., 0.)).state
        self.assertEqual(state, 'MEMORIA')


class RacingLineTests(unittest.TestCase):
    """Curva a frente: referencia para fora (abre antes da curva), so em pista estreita."""
    def follower(self, **extra):
        settings = dict(FollowerTests.settings, steering_law='stanley', racing_line_m=.10, racing_inside=1.,
                        racing_filter_s=0.)
        settings.update(extra)
        return RealStanleyFollower(settings)

    def offset(self, follower, curvature_now, dkappa, width):
        follower.path_dkappa = dkappa
        return follower._racing_line_offset(curvature_now, SimpleNamespace(corridor_width_m=width), .02)

    def test_opens_to_the_outside_before_a_left_curve(self):
        follower = self.follower()
        before = self.offset(follower, 0., .8, 1.3)   # reta agora, curva a esquerda a frente
        self.assertAlmostEqual(before, -.10)          # carro para a DIREITA (fora)
        inside = self.offset(follower, .8, 0., 1.3)   # ja na curva: volta ao centro (so abre)
        self.assertAlmostEqual(inside, 0., places=6)
        right = self.offset(follower, 0., -.8, 1.3)   # curva a direita: abre para a esquerda
        self.assertAlmostEqual(right, .10)

    def test_wide_track_and_missing_width_disable_it(self):
        follower = self.follower()
        self.assertEqual(self.offset(follower, 0., .8, 1.9), 0.)
        self.assertAlmostEqual(self.offset(follower, 0., .8, 1.5), -.05)  # meio caminho
        self.assertEqual(self.offset(follower, 0., .8, float('nan')), 0.)
        self.assertEqual(self.offset(self.follower(racing_line_m=0.), 0., .8, 1.3), 0.)

    def test_the_offset_moves_the_stanley_reference(self):
        car = fake_car()
        follower = self.follower(stanley_use_vref=False)
        from fva_car.cones import ConeObservation
        follower.apply(car, ConeObservation(10., errors=(0., 0., 0.), path_dkappa=.8, corridor_width_m=1.3), 10.)
        self.assertLess(follower.controller.cross_track_term, 0.)  # esterca para a direita (abre)


class GateStartTests(unittest.TestCase):
    def test_one_cone_per_side_starts_with_the_pair_as_first_guess(self):
        from fva_car.corridor import CorridorEstimator, CorridorSettings
        estimator = CorridorEstimator(CorridorSettings(track_width_m=.9))
        left, right = np.array([[1.7, .95]]), np.array([[1.75, -.95]])  # pista de 1,9 m, palpite 0,9
        for k in range(3):
            estimator.step(10. + .1*k, left, right, (0., 0., 0.) if k else None)
        self.assertIsNotNone(estimator.x)
        self.assertAlmostEqual(estimator.x[4], 1.9, delta=.15)
        self.assertLess(abs(math.degrees(estimator.x[1])), 5.)  # nao gira o corredor para caber
